// Jerrin Shirks

#include <sys/stat.h>
#include <fstream>
#include <string>

#include <iostream>
#include <vector>
#include <map>
#include <cstring>
#include <filesystem>
#include <unistd.h>



#ifndef CHUZ
#define CHUZ


#if defined(WIN32) || defined(_WIN32) || defined(__WIN32) && !defined(__CYGWIN__)
static const std::string VERSION="WINDOWS";
#else
static const std::string VERSION="LINUX";
#endif



//#define std::cout std::cout
//#define std::endl std::endl

using namespace std;



class Save
{
public:
    int filesize;
    string filename;
    unsigned char* bytes;
    int INDEX_CHUZ;
    int INDEX_HEAD;


    Save() {}

    // Constructor
    Save(string file) {
        filename = file;
        filesize = GetFileSize(filename);
        INDEX_CHUZ = filesize - 1512;
        INDEX_HEAD = 0;
        bytes = new unsigned char[filesize];
        ifstream infile(filename, ios::in | ios::binary);
        infile.read((char *) & bytes[0], filesize);
        infile.close();
    }

    void NewSave() {



        std::ofstream out(filename, std::ios::binary);
        std::cout << "File Size: " << GetFileSize(filename) << std::endl;
        out.write((char*)&bytes[0], filesize);
        out.close();
        std::cout << "Created the new save file!" << std::endl;

    }


    std::string GetGamemode() {
        if (filename.find("SPEEDCHUZZLE") != std::string::npos) {
            return "Speed";
        } else if (filename.find("CHUZZLEPUZZLE") != std::string::npos) {
            return "Classic";
        } else {
            return "?????";
        }
    }

    std::string GetSaveName() {
        return "NA";
    }


    // GetFileSize
    long GetFileSize(std::string filename)
    {
        struct stat stat_buf;
        int rc = stat(filename.c_str(), &stat_buf);
        return rc == 0 ? stat_buf.st_size : -1;
    }


    // Set Body Color
    void SetColor(char chuzzle, int colorValue) {
        int newIndex = INDEX_CHUZ + 1 + 42 * chuzzle;
        bytes[newIndex] = colorValue;
    }
    // Get Body Color
    int GetColor(char chuzzle) {
      int newIndex = INDEX_CHUZ + 1 + 42 * chuzzle;
      return bytes[newIndex];
    }

    // Eye Color
    bool SetEyeColor(char chuzzle, int colorValue) {
        if (colorValue < 0 || colorValue > 5) {return false;}
        int newIndex = INDEX_CHUZ + 17 + 42 * chuzzle;
        bytes[newIndex] = colorValue;
        return true;
    }
    // Get Eye Color
    int GetEyeColor(char chuzzle) {
      int newIndex = INDEX_CHUZ + 17 + 42 * chuzzle;
      return bytes[newIndex];
    }

    // Set Lock
    void SetLock(char chuzzle, bool lockValue) {
        int newIndex = INDEX_CHUZ + 35 + 42 * chuzzle;
        bytes[newIndex] = (lockValue == true) ? 1 : 0;
    }
    // Get Lock
    bool GetLock(char chuzzle) {
      int newIndex = INDEX_CHUZ + 35 + 42 * chuzzle;
      return (bytes[newIndex] == 0) ? false : true;
    }


    // Set Bomb
    void SetBomb(char chuzzle, bool bombValue) {
        int newIndex = INDEX_CHUZ + 40 + 42 * chuzzle;
        bytes[newIndex] = (bombValue == true) ? 1 : 0;
    }
    // Get Bomb
    bool GetBomb(char chuzzle) {
      int newIndex = INDEX_CHUZ + 40 + 42 * chuzzle;
      return (bytes[newIndex] == 0) ? false : true;
    }


    // Set Point
    void SetPoint(char chuzzle, int point, int value) {
        int newIndex = INDEX_CHUZ + point + 42 * chuzzle;
        bytes[newIndex] = value;
    }

    // Get Point
    int GetPoint(char chuzzle, int point) {
    int newIndex = INDEX_CHUZ + point + 42 * chuzzle;
    return bytes[newIndex];
    }

    // set Header
    bool SetHeader(char row, int point, int value) {
        if (value < 0) { return false; }
        int newIndex = INDEX_HEAD + point + 28 * row;
        bytes[newIndex] = value;
        return true;
    }

    // get Header
    int GetHeader(char row, int point) {
        int newIndex = INDEX_HEAD + point + 28 * row;
        return bytes[newIndex];
    }

    // remove all fat garbage
    void ClearFat() {
        for (int i = 0; i < 36; ++i) {
            vector<int> fats = {25,26,29,30,33,34};
            for (int j : fats) {
              SetPoint(i, j, 0);
            }
        }
    }

    void SetShape(char chuzzle, char type) {
        if (type == 0) {
            // reg
            vector<int> fats = {25,26,29,30,33,34};
            for (int j : fats) {SetPoint(chuzzle, j, 0);}

        } else if (type == 1) {
            // fat top left
            SetPoint(chuzzle, 25, 1);
            SetPoint(chuzzle, 26, 0);
            SetPoint(chuzzle, 29, 0);
            SetPoint(chuzzle, 30, 0);
            SetPoint(chuzzle, 33, 0);
            SetPoint(chuzzle, 34, 0);

        } else if (type == 2) {
            // fat top right
            SetPoint(chuzzle, 25, 0);
            SetPoint(chuzzle, 26, 1);
            SetPoint(chuzzle, 29, 191);
            SetPoint(chuzzle, 30, 128);
            SetPoint(chuzzle, 33, 0);
            SetPoint(chuzzle, 34, 0);

        } else if (type == 3) {
            // fat bottom left
            SetPoint(chuzzle, 25, 0);
            SetPoint(chuzzle, 26, 1);
            SetPoint(chuzzle, 29, 0);
            SetPoint(chuzzle, 30, 0);
            SetPoint(chuzzle, 33, 191);
            SetPoint(chuzzle, 34, 121);

        } else if (type == 4) {
            // fat bottom right
            SetPoint(chuzzle, 25, 0);
            SetPoint(chuzzle, 26, 1);
            SetPoint(chuzzle, 29, 191);
            SetPoint(chuzzle, 30, 128);
            SetPoint(chuzzle, 33, 191);
            SetPoint(chuzzle, 34, 128);
        }
    }

    int GetShape(char chuzzle) {
        bool bottom = GetPoint(chuzzle, 29) == 0;
        bool top    = GetPoint(chuzzle, 33) == 0;
        if (GetPoint(chuzzle, 25) == 0 && GetPoint(chuzzle, 26) == 0) {
            return 0;
        } else {
            if (GetPoint(chuzzle, 25) == 1) {
                return 1;
            } else if (bottom == true && top == false) {
                return 3;
            } else if (bottom == false && top == true) {
                return 2;
            } else {
                return 4;
            }
        }


        return 0;
    }



    long SetScore(long newScore) {
        SetHeader(0, 14,  newScore            % 256);
        SetHeader(0, 15, (newScore /     256) % 256);
        SetHeader(0, 16, (newScore /   65536) % 256);
        SetHeader(0, 17, (newScore /16777216) % 256);
        return 0;
    }

    long GetScore() {
        return GetHeader(0,14) + 256 * GetHeader(0,15) + 65536 * GetHeader(0,16) + 16777216 * GetHeader(0,17);
    }

    long SetScrambles(int newScrambles) {
        SetHeader(0, 18, newScrambles);
        return 0;
    }

    int GetScrambles() {
        return GetHeader(0, 18);

    }

    long SetLevel(long newLevel) {
        SetHeader(1, 18,  newLevel            % 256);
        SetHeader(1, 19, (newLevel /     256) % 256);
        SetHeader(1, 20, (newLevel /   65536) % 256);
        SetHeader(1, 21, (newLevel /16777216) % 256);
        return 0;
    }

    long GetLevel() {
        return GetHeader(1,18) + 256 * GetHeader(1,19) + 65536 * GetHeader(1,20);
    }









    // Display Board Data
    void DisplayChuzzleBytes() {
        int n = 0;
        int count = 0;
        int line = 1;
        string y = "---------------------------------------------------------------";
        std::cout << "        0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41" << std::endl;
        std::cout << "    +" << y << y << "-" << std::endl;
        std::cout << "  0 | ";

        for (int _ = INDEX_CHUZ; _ < filesize; ++_) {
            n = bytes[_];
            if (n < 10) { std::cout << " "; }
            if (n < 100) { std::cout << " "; }
            std::cout << n;
            if ((count + 1) % 42 == 0) {
                std::cout << std::endl;
                if (line < 10) { std::cout << " ";}
                std::cout << " " << line << " | ";
                ++line;
            }
            ++count;
        }
        std::cout << std::endl << "Count: " << count << std::endl;
    }

    // Display Board Data
    void DisplayBoardBytes() {
        int n = 0;
        int count = 0;
        int line = 1;
        string y = "------------------------------------------";
        std::cout << "        0  1  2  3  4  5  6  7  8  9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27" << std::endl;
        std::cout << "    +" << y << y << "-" << std::endl;
        std::cout << "  0 | ";

        for (int _ = 0; _ < INDEX_CHUZ; ++_) {
            n = bytes[_];
            if (n < 10) { std::cout << " "; }
            if (n < 100) { std::cout << " "; }
            if (n == 0) { std::cout << "."; }
            else { std::cout << n; }
            if ((count + 1) % 28 == 0) {
                std::cout << std::endl;
                if (line < 10) { std::cout << " "; }
                std::cout << " " << line << " | ";
                ++line;
            }
            ++count;
        }
        std::cout << std::endl << "Count: " << count << std::endl;
    }

};


#endif


/*

int main()
{
    std::cout << std::endl << std::endl << std::endl;
    auto save = Save("C:\\Users\\jerrin\\Documents\\my games\\Chuzzle\\Profiles\\Jerrin\\hold\\SAVEGAME-SPEEDCHUZZLE.DAT");
    std::cout << "Filesize: " << save.filesize << std::endl;
    save.ClearFat();

    for (int i = 0; i < 36; ++i) {
      //save.SetColor(i, i%8);
      //save.SetEyeColor(i, i%6);
      //save.SetBomb(i, true);
      //save.SetLock(i, true);
       //save.SetPoint(i, 25, 1);
       //save.SetPoint(i, 26, 1);
       //save.SetPoint(2, 29, 128);
       //save.SetPoint(2, 30, 191);
        //save.SetPoint(i, 21, 0);
        //save.SetPoint(i, 22, 0);
        //save.SetPoint(i, 23, 65);  // part of eyeballs?
        //save.SetPoint(i, 24, 65); // part of eyeballs?
    }
    //save.SetHeader(0, 12, 128);


    // Score (They use signed int!)
    //save.SetHeader(0, 14, 0); // 1 = 1
    //save.SetHeader(0, 15, 0); // 1 = 256
    //save.SetHeader(0, 16, 0); // 1 = 65536
    //save.SetHeader(0, 17, 0); // 1 = 16777216

    // Amount of Scrambles
    //save.SetHeader(0, 18, 3);

    // Level Number
    save.SetHeader(1, 18, 0); // 1 = 1
    save.SetHeader(1, 19, 0); // 1 = 256
    save.SetHeader(1, 20, 1); // 1 = 65536


    //save.SetHeader(2, 6, 0);
    //save.SetHeader(2, 7, 0);
    //save.SetHeader(2, 8, 0);

    //?
    //save.SetHeader(1, 22, 0);
    //save.SetHeader(1, 23, 0);
    //save.SetHeader(1, 24, 0);
    //save.SetHeader(1, 25, 0);



    save.DisplayBoardBytes();

    save.NewSave();


    return 0;
}
*/



/*


Bytes That Change:
[0,14] - [0,15]
[2,6]  - [2,8]
[4,22]
[1,22] - [1-25]









*/






















/*
Body Color (Index 1)
red     0
green   1
blue    2
orange  3
yellow  4
purple  5
white   6
cyan    7


Eye Color (Index 17)
cyan    0
brown   1
green   2
magenta 3
purple  4
black   5


IsLock (Index 35)
False   0
True    1


IsBomb (Index 40)
False   0
True    1



// Fat Stuff

Top Left
(Index 25) = 1

Bottom Left
(Index 26) = 1
(Index 33) = 128
(Index 34) = 191

Top Right
(Index 26) = 1
(Index 29) = 128
(Index 30) = 191

Bottom Right
(Index 26) = 1

(Index 33) = 128
(Index 34) = 191











*/


/*
    unsigned char GetValue(int chuzzle, int point) {
      //std::cout<<chuzzle<<" "<<pointers[point][0]<<pointers[point][1]<<std::endl;
      std::cout << "Value: " << (int)bytes[INDEX_CHUZ + 42 * chuzzle + point] << std::endl;
      return 0;
    }






red     0  (255,0,0)
green   1 (0,255,0)
blue    2 (0,0,255)
orange  3 (255,165,0)
yellow  4 (255,255,0)
purple  5 (128,0,128)
white   6 (255,255,255)
cyan    7 (0,255,255)
black   8+ (0,0,0)




*/










