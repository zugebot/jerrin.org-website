// 515

#include "speedwindow.h"

#include <QApplication>
#include <QTabWidget>
#include <QMainWindow>
#include <QStyleFactory>


int main(int argc, char *argv[])
{

    QApplication app(argc, argv);
    //SmallWindow *window = new SmallWindow;
    QMainWindow *window = new QMainWindow();

    int WindowHight = 850;
    int WindowWidth = 410;


    window->setWindowTitle(QString::fromUtf8("Chuzzle Save Editor"));
    window->resize(WindowHight, WindowWidth);





    // Dark mode?
    qApp->setStyle(QStyleFactory::create("Fusion"));

    QPalette newPalette;
    newPalette.setColor(QPalette::Window,          QColor( 37,  37,  37));
    newPalette.setColor(QPalette::WindowText,      QColor(212, 212, 212));
    newPalette.setColor(QPalette::Base,            QColor( 60,  60,  60));
    newPalette.setColor(QPalette::AlternateBase,   QColor( 45,  45,  45));
    newPalette.setColor(QPalette::PlaceholderText, QColor(127, 127, 127));
    newPalette.setColor(QPalette::Text,            QColor(255, 255, 255));
    newPalette.setColor(QPalette::Button,          QColor( 45,  45,  45));
    newPalette.setColor(QPalette::ButtonText,      QColor(212, 212, 212));
    newPalette.setColor(QPalette::BrightText,      QColor(240, 240, 240));
    newPalette.setColor(QPalette::Highlight,       QColor( 38,  79, 120));
    newPalette.setColor(QPalette::HighlightedText, QColor(240, 240, 240));

    newPalette.setColor(QPalette::Light,           QColor( 60,  60,  60));
    newPalette.setColor(QPalette::Midlight,        QColor( 52,  52,  52));
    newPalette.setColor(QPalette::Dark,            QColor( 30,  30,  30) );
    newPalette.setColor(QPalette::Mid,             QColor( 37,  37,  37));
    newPalette.setColor(QPalette::Shadow,          QColor( 0,    0,   0));


    newPalette.setColor(QPalette::Disabled, QPalette::Text, QColor(127, 127, 127));

    qApp->setPalette(newPalette);





    QWidget * centralWidget = new QWidget;
    QTabWidget *tabs = new QTabWidget(centralWidget);




    tabs->setFixedSize(WindowHight, WindowWidth);
    //tabs->addTab(new PracticeWindow(),"Practice");
    //tabs->addTab(new SpeedWindow(),"Speed");
    //tabs->addTab(new RevisedWindow(),"Revised Speed");
    tabs->addTab(new SpeedWindow(argv[0]),"Classic and Speed");

    window->setCentralWidget(centralWidget);
    window->show();



    app.setWindowIcon(QIcon(":/sprites/bottle.png"));
    app.exec();
    return 0;
}

