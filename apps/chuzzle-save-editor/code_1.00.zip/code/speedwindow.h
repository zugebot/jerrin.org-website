#ifndef SPEEDWINDOW_H
#define SPEEDWINDOW_H

#include <QWidget>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QLineEdit>
#include <QTextEdit>
#include <QPushButton>
#include <QPixmap>
#include <QIcon>
#include <QSignalMapper>
#include <QFileDialog>
#include <QMenuBar>
#include <QIntValidator>
#include <QLabel>
#include <QDesktopServices>

#include <map>
#include <string>
#include <iostream>

#include "chuzzlesaveeditor.h"

class SpeedWindow : public QWidget
{
    Q_OBJECT
public:

    bool FileIsOpen = false;
    int InputType = 0;
    int InputColor = 0;     // Type = 0
    int InputShape = 0;     // Type = 1
    int InputSuperBomb = 0; // Type = 2

    Save save = Save();


    QString filePath = "Speed";
    std::map <int, std::string> chuzzleSprites;
    std::map <int, std::string> rgbColors = {
    {0, "background-color: rgb(255,  0,  0)"}, //red
    {1, "background-color: rgb(  0,255,  0)"}, //green
    {2, "background-color: rgb(  0,  0,255)"}, //blue
    {3, "background-color: rgb(255,165,  0)"}, //orange
    {4, "background-color: rgb(255,255,  0)"}, //yellow
    {5, "background-color: rgb(128,  0,128)"}, //purple
    {6, "background-color: rgb(255,255,255)"}, //white
    {7, "background-color: rgb(  0,255,255)"}, //cyan
    {8, "background-color: rgb(  0,  0,  0)"}, //rainbow
    };
    std::map <int, QString> nameColors = {
    {0, "Red"},
    {1, "Green"},
    {2, "Blue"},
    {3, "Orange"},
    {4, "Yellow"},
    {5, "Purple"},
    {6, "White"},
    {7, "Cyan"},
    {8, "Rainbow"},
    {9, "???"}
    };


    SpeedWindow(char* path) : QWidget()
    {
      // Creates File Path
      if (true) {
      filePath = path;
      filePath.resize(filePath.size()-17);

      std::string temp = filePath.toStdString();
      char ch1 = '\\';char ch2 = '/';
      for (int i = 0; i < (int)temp.length(); ++i) {
          if (temp[i] == ch1)
            temp[i] = ch2;
        }
        filePath = QString::fromStdString(temp);
        std::cout << "Path: " << filePath.toStdString() << std::endl;
      }

      // Creates Chuzzle Sprite Map
      if (true) {
          chuzzleSprites = {
          {0, "chuzzlesReg/chuzzle00.png"}, //red
              {1, "chuzzlesReg/chuzzle01.png"}, //red
              {2, "chuzzlesReg/chuzzle02.png"}, //red
              {3, "chuzzlesReg/chuzzle03.png"}, //red
              {4, "chuzzlesReg/chuzzle04.png"}, //red
          {5, "chuzzlesReg/chuzzle05.png"}, //green
              {6, "chuzzlesReg/chuzzle06.png"}, //green
              {7, "chuzzlesReg/chuzzle07.png"}, //green
              {8, "chuzzlesReg/chuzzle08.png"}, //green
              {9, "chuzzlesReg/chuzzle09.png"}, //green
          {10, "chuzzlesReg/chuzzle10.png"}, //blue
              {11, "chuzzlesReg/chuzzle11.png"}, //blue
              {12, "chuzzlesReg/chuzzle12.png"}, //blue
              {13, "chuzzlesReg/chuzzle13.png"}, //blue
              {14, "chuzzlesReg/chuzzle14.png"}, //blue
          {15, "chuzzlesReg/chuzzle15.png"}, //orange
              {16, "chuzzlesReg/chuzzle16.png"}, //orange
              {17, "chuzzlesReg/chuzzle17.png"}, //orange
              {18, "chuzzlesReg/chuzzle18.png"}, //orange
              {19, "chuzzlesReg/chuzzle19.png"}, //orange
          {20, "chuzzlesReg/chuzzle20.png"}, //yellow
              {21, "chuzzlesReg/chuzzle21.png"}, //yellow
              {22, "chuzzlesReg/chuzzle22.png"}, //yellow
              {23, "chuzzlesReg/chuzzle23.png"}, //yellow
              {24, "chuzzlesReg/chuzzle24.png"}, //yellow
          {25, "chuzzlesReg/chuzzle25.png"}, //purple
              {26, "chuzzlesReg/chuzzle26.png"}, //purple
              {27, "chuzzlesReg/chuzzle27.png"}, //purple
              {28, "chuzzlesReg/chuzzle28.png"}, //purple
              {29, "chuzzlesReg/chuzzle29.png"}, //purple
          {30, "chuzzlesReg/chuzzle30.png"}, //white
              {31, "chuzzlesReg/chuzzle31.png"}, //white
              {32, "chuzzlesReg/chuzzle32.png"}, //white
              {33, "chuzzlesReg/chuzzle33.png"}, //white
              {34, "chuzzlesReg/chuzzle34.png"}, //white
          {35, "chuzzlesReg/chuzzle35.png"}, //cyan
              {36, "chuzzlesReg/chuzzle36.png"}, //cyan
              {37, "chuzzlesReg/chuzzle37.png"}, //cyan
              {38, "chuzzlesReg/chuzzle38.png"}, //cyan
              {39, "chuzzlesReg/chuzzle39.png"}, //cyan
          {40, "chuzzlesReg/chuzzle40.png"}, //rainbow!
              {41, "chuzzlesReg/chuzzle41.png"} //empty


          };
      }


      QMenuBar *bar = new QMenuBar();

      // File
      QMenu *fileMenu = bar->addMenu(tr("&File"));

      QAction *mOpen = new QAction("Open");
      fileMenu->addAction(mOpen);
      connect(mOpen, &QAction::triggered, this, [=](){OpenFile();});

      QAction *mSave = new QAction("Save");
      fileMenu->addAction(mSave);
      connect(mSave, &QAction::triggered, this, [=](){SaveFile();});

      // About
      QMenu *AboutMenu = bar->addMenu(tr("&Help"));

      QAction *mAbout = new QAction("Made by Jerrin Shirks!");
      AboutMenu->addAction(mAbout);

      QAction *mVersion = new QAction("Version 1.00");
      AboutMenu->addAction(mVersion);

      QAction *mDate = new QAction("June 3rd, 2022");
      AboutMenu->addAction(mDate);


      QAction *mHowToUse = new QAction("How To Use");
      AboutMenu->addAction(mHowToUse);
      connect(mHowToUse, &QAction::triggered, this, [=](){OpenWebsite("https://jerrin.org/apps/chuzzle-save-editor/how-to-use.html");});


      Mainlayout->layout()->setMenuBar(bar);

      setFixedSize(900,480);
      Mainlayout->addLayout(Leftlayout);
      Mainlayout->addLayout(Rightlayout);
      Leftlayout->addLayout(gridLL);
      Leftlayout->addLayout(boxLR);


      boxLR->addWidget(currentSaveLbl);
      boxLR->addWidget(currentTypelbl);
      boxLR->addWidget(currentPaintLbl);
      boxLR->addLayout(gridLR);
      boxLR->addLayout(bottomLR);



      Rightlayout->addLayout(gridRL);
      Rightlayout->addLayout(gridRR);



      // For gridLL
      if (true) {
          // This is for the LL segment.


          // Score
          QHBoxLayout *box00 = new QHBoxLayout;
          gridLL->addLayout(box00);
          LLbtn00->setText("Set Score");
          box00->addWidget(LLbtn00);

          LLlin01->setValidator( new QIntValidator(0, 2147483647, this) );
          connect(LLbtn00, &QPushButton::clicked, this, [=](){
              save.SetScore(std::stol( LLlin01->text().toStdString()) );
              LLlab10->setText("Current Score: " + toQString(save.GetScore()));
          });
          box00->addWidget(LLlin01);

          LLlab10->setText("Current Score: N/A");
          LLlab10->setAlignment(Qt::AlignCenter);
          gridLL->addWidget(LLlab10);



          // Level

          QHBoxLayout *box20 = new QHBoxLayout;
          gridLL->addLayout(box20);

          LLbtn20->setText("Set Level");
          box20->addWidget(LLbtn20);

          LLlin01->setValidator( new QIntValidator(0, 2147483647, this) );
          connect(LLbtn20, &QPushButton::clicked, this, [=](){
              LLlin21->setText(QString::fromStdString(std::to_string(save.GetLevel())));
              LLlab30->setText("Current Level: " + toQString(save.GetLevel()));
          });
          box20->addWidget(LLlin21);


          LLlab30->setText("Current Level: N/A");
          LLlab30->setAlignment(Qt::AlignCenter);
          gridLL->addWidget(LLlab30);



          // Scrambles

          QHBoxLayout *box40 = new QHBoxLayout;
          gridLL->addLayout(box40);

          LLbtn40->setText("Set Scrambles");
          box40->addWidget(LLbtn40);

          LLlin41->setValidator( new QIntValidator(0,  255, this) );
          connect(LLbtn40, &QPushButton::clicked, this, [=](){
              LLlin41->setText(QString::fromStdString(std::to_string(save.GetScore())));
          });
          box40->addWidget(LLlin41);

          LLlab50->setText("Current Scrambles: NA");
          LLlab50->setAlignment(Qt::AlignCenter);
          gridLL->addWidget(LLlab50);




          // Bottle

          QHBoxLayout *box60 = new QHBoxLayout;
          gridLL->addLayout(box60);

          LLbtn60->setText("Set Bottle");
          box60->addWidget(LLbtn60);

          LLlin61->setValidator( new QIntValidator(0, 2147483647, this) );
          connect(LLbtn60, &QPushButton::clicked, this, [=](){LLlin61->setText(QString::fromStdString(std::to_string(save.GetScore())));});
          box60->addWidget(LLlin61);

          LLlab70->setText("Current Bottle: NA / NA");
          LLlab70->setAlignment(Qt::AlignCenter);
          gridLL->addWidget(LLlab70);



      }







      // This is for the LR segment (buttons)


      if (true) {

        // Funny last label
        currentPaintLbl->setAlignment(Qt::AlignCenter);
        currentTypelbl->setAlignment(Qt::AlignCenter);


        // Shapes
        QPushButton *LRbtn00 = DrawButton("chuzzlesReg/chuzzle00.png");
        gridLR->addWidget(LRbtn00, 0, 0);
        connect(LRbtn00, &QPushButton::clicked, this, [=](){ClickedInputShape(0);});

        QPushButton *LRbtn01 = DrawButton("chuzzlesReg/chuzzle01.png");
        gridLR->addWidget(LRbtn01, 0, 1);
        connect(LRbtn01, &QPushButton::clicked, this, [=](){ClickedInputShape(1);});

        QPushButton *LRbtn02 = DrawButton("chuzzlesReg/chuzzle02.png");
        gridLR->addWidget(LRbtn02, 0, 2);
        connect(LRbtn02, &QPushButton::clicked, this, [=](){ClickedInputShape(2);});

        QPushButton *LRbtn03 = DrawButton("chuzzlesReg/chuzzle03.png");
        gridLR->addWidget(LRbtn03, 0, 3);
        connect(LRbtn03, &QPushButton::clicked, this, [=](){ClickedInputShape(3);});

        QPushButton *LRbtn10 = DrawButton("chuzzlesReg/chuzzle04.png");
        gridLR->addWidget(LRbtn10, 0, 4);
        connect(LRbtn10, &QPushButton::clicked, this, [=](){ClickedInputShape(4);});

        // Colors
        QPushButton *LRbtn11 = DrawButton(0);
        gridLR->addWidget(LRbtn11, 1, 0);
        connect(LRbtn11, &QPushButton::clicked, this, [=](){ClickedInputColor(0);});

        QPushButton *LRbtn12 = DrawButton(1);
        gridLR->addWidget(LRbtn12, 1, 1);
        connect(LRbtn12, &QPushButton::clicked, this, [=](){ClickedInputColor(1);});

        QPushButton *LRbtn13 = DrawButton(2);
        gridLR->addWidget(LRbtn13, 1, 2);
        connect(LRbtn13, &QPushButton::clicked, this, [=](){ClickedInputColor(2);});

         QPushButton *LRbtn20 = DrawButton(3);
        gridLR->addWidget(LRbtn20, 1, 3);
        connect(LRbtn20, &QPushButton::clicked, this, [=](){ClickedInputColor(3);});

        QPushButton *LRbtn21 = DrawButton(4);
        gridLR->addWidget(LRbtn21, 1, 4);
        connect(LRbtn21, &QPushButton::clicked, this, [=](){ClickedInputColor(4);});

        QPushButton *LRbtn22 = DrawButton(5);
        gridLR->addWidget(LRbtn22, 2, 0);
        connect(LRbtn22, &QPushButton::clicked, this, [=](){ClickedInputColor(5);});

        QPushButton *LRbtn23 = DrawButton(6);
        gridLR->addWidget(LRbtn23, 2, 1);
        connect(LRbtn23, &QPushButton::clicked, this, [=](){ClickedInputColor(6);});

        QPushButton *LRbtn30 = DrawButton(7);
        gridLR->addWidget(LRbtn30, 2, 2);
        connect(LRbtn30, &QPushButton::clicked, this, [=](){ClickedInputColor(7);});

        QPushButton *LRbtn31 = DrawButton("Rainbow", 8);
        gridLR->addWidget(LRbtn31, 2, 3);
        connect(LRbtn31, &QPushButton::clicked, this, [=](){ClickedInputColor(8);});

        // Other
        QPushButton *LRbtn32 = DrawButton();
        gridLR->addWidget(LRbtn32, 2, 4);
        connect(LRbtn32, &QPushButton::clicked, this, [=](){});

        QPushButton *LRbtn33 = DrawButton("Super",0);
        bottomLR->addWidget(LRbtn33);
        connect(LRbtn33, &QPushButton::clicked, this, [=](){ClickedInputSuperBomb(0);});

        QPushButton *LRbtn40 = DrawButton("Lock",0);
        bottomLR->addWidget(LRbtn40);
        connect(LRbtn40, &QPushButton::clicked, this, [=](){ClickedInputSuperBomb(1);});

        QPushButton *LRbtn41 = DrawButton();
        bottomLR->addWidget(LRbtn41);
        connect(LRbtn41, &QPushButton::clicked, this, [=](){});

        QLineEdit   *LRlin42 = LineEdit();
        bottomLR->addWidget(LRlin42);
        //connect(LRlin42, &QPushButton::clicked, this, [=](){});

      }







      // This is for RL segment (board)
      if (true) {
      QPushButton *temp;
      chuzzleGrid.resize(6);
      for (int y=0;y<6;y++) {
        chuzzleGrid[y].resize(6);
        for(int x=0;x<6;x++) {
          temp = ChuzzleButton("");
          connect(temp, &QPushButton::clicked , this, [=](){ClickedChuzzle(x+y*6);});
          gridRL->addWidget(temp,x,y);
          chuzzleGrid[y][x] = temp;
        }
      }
    }






      window->setLayout(Mainlayout);
    }





private slots:

    void OpenWebsite(QString link) {
      QDesktopServices::openUrl(QUrl(link));
    }


    void ShowLastClicked(QString message) {
        currentPaintLbl->setText("Last Clicked: " + message);
    }

    QString toQString(long num) {
        return QString::fromStdString(std::to_string(num));
    }

  void ClickedInputColor(int val) {
        InputType = 0;
        InputColor = val;
        ShowLastClicked("Color->" + ((val >= 0 && val <= 8) ? nameColors[val] : nameColors[9]));
        std::cout<<InputType<<" "<<InputColor<<" "<<InputShape<<" "<<std::endl;
  }

  void ClickedInputShape(int val) {
      InputType = 1;
      InputShape = val;
      if (val == 0) {
        ShowLastClicked("Shape->Normal");
      } else {
        ShowLastClicked("Shape->Fat" + toQString(val));
      }

      std::cout<<InputType<<" "<<InputColor<<" "<<InputShape<<" "<<std::endl;

  }

  void ClickedInputSuperBomb(int val) {
      InputType = 2;
      InputSuperBomb = val;
      ShowLastClicked("Feature->" + (QString)((val == 0) ? "Super" : "Lock"));
      std::cout<<InputType<<" "<<InputColor<<" "<<InputShape<<" "<<std::endl;
  }



  void ClickedChuzzle(int chuzzle) {
      int tempColor; int tempShape;
      if (FileIsOpen == false) {return;}

    // Color Chosen
    if (InputType == 0) {
        chuzzleGrid[chuzzle/6][chuzzle%6]->setStyleSheet("");

        // if fat segment trying to make it rainbow, make it no longer fat
        if (InputColor == 8) {
            save.SetShape(chuzzle, 0);
            save.SetColor(chuzzle, InputColor);
            tempColor = 8;
            tempShape = 0;
        } else { // else do whatever the variables say
            save.SetColor(chuzzle, InputColor);
            tempColor = save.GetColor(chuzzle);
            tempShape = save.GetShape(chuzzle);
        }
        chuzzleGrid[chuzzle/6][chuzzle%6]->setStyleSheet("font-weight: bold; color: white; background-image:url(" + filePath +
             QString::fromStdString(chuzzleSprites[tempColor * 5 + tempShape]) + ");");


    // Shape Chosen
    } else if (InputType == 1) {
        chuzzleGrid[chuzzle/6][chuzzle%6]->setStyleSheet("");

        //if rainbow make it not a fat segment
        if (save.GetColor(chuzzle) == 8) {
            save.SetColor(chuzzle, 0);}

        save.SetShape(chuzzle, InputShape);

        int tempColor = save.GetColor(chuzzle);
        if (tempColor > 8) {tempColor = 8;}
        int tempShape = save.GetShape(chuzzle);
        chuzzleGrid[chuzzle/6][chuzzle%6]->setStyleSheet("font-weight: bold; color: white; background-image:url(" + filePath +
             QString::fromStdString(chuzzleSprites[tempColor * 5 + tempShape]) + ");");

    // Feature Chosen
    } else if (InputType == 2) {
        bool isLock  = save.GetLock(chuzzle);
        bool isSuper = save.GetBomb(chuzzle);

        if (InputSuperBomb == 0) {
            isSuper = !isSuper;
            save.SetBomb(chuzzle, isSuper);

        } else if (InputSuperBomb == 1) {
            isLock = !isLock;
            save.SetLock(chuzzle, isLock);
        }

        // Fix the text for that button
        QString text;
        if (isSuper) {text += "B";}
        if (isLock) {text += "L";}
        chuzzleGrid[chuzzle/6][chuzzle%6]->setText(text);


    }
  }




private:

    // Button Template
    QPushButton* Button() {
      QPushButton *button = new QPushButton;
      button->setFixedSize(100,50);
     return button;
    }

    // Type Button Template
    QPushButton* DrawButton(QString image) { // Image Version
      QPushButton *button = new QPushButton;
      std::cout << "image: " << filePath.toStdString() << image.toStdString() << std::endl;
      button->setStyleSheet("font-weight: bold; color: white; background-image:url(" + filePath + image + ");");
      //button->setText("test");
      button->setFixedSize(50,50);
      return button;}

    // Type Button Template
    QPushButton* DrawButton(int color) {    // Color Version
      QPushButton *button = new QPushButton;
      button->setStyleSheet(QString::fromStdString(rgbColors[color]));
      button->setFixedSize(50,50);
     return button;}    // Type Button Template

    QPushButton* DrawButton(QString yes, int x) {    // Color Version
      QPushButton *button = new QPushButton;
      button->setText(yes);
      button->setFixedSize(50,50);
     return button;}

    // Type Button Template
    QPushButton* DrawButton() {             // Empty Version
      QPushButton *button = new QPushButton;
      button->setFixedSize(50,50);
     return button;}

    // LineEdit Template
    QLineEdit* LineEdit() {
      QLineEdit *lineEdit = new QLineEdit;
      lineEdit->setFixedSize(100,50);
     return lineEdit;
    }

    // Chuzzle Template
    QPushButton *ChuzzleButton(QString text) {
      QPushButton *button = new QPushButton;
      button->setFixedSize(50,50);
      button->setText(text);
      button->setStyleSheet("font-weight: bold; color: black;");
     return button;
    }



    // Open File!
    void OpenFile() {

      QString QFileName = QFileDialog::getOpenFileName(this,
          tr("Open Chuzzle DAT file"), "", tr("Image Files (*.DAT)"));
      if (QFileName.isEmpty()) {return;}
      save = Save(QFileName.toStdString());
      // make it
      //
      currentTypelbl->setText("Editing Gamemode: " + QString::fromStdString(save.GetGamemode()));
      std::cout << save.filename << std::endl;
      save.DisplayBoardBytes();
      //save.DisplayChuzzleBytes();

      std::cout << "value:" << save.GetColor(0) << std::endl;

      int tempColor = 0;
      int tempShape = 0;
      bool isLock;
      bool isSuper;
      QString text;

      for (int y=0;y<6;y++) {
        for(int x=0;x<6;x++) {

          // Creates shape and color
          tempColor = save.GetColor(x * 6 + y);
          tempShape = save.GetShape(x * 6 + y);
          chuzzleGrid[x][y]->setStyleSheet("background-image:url(" + filePath +
               QString::fromStdString(chuzzleSprites[tempColor * 5 + tempShape]) + ");");

          isLock  = save.GetLock(x * 6 + y);
          isSuper = save.GetBomb(x * 6 + y);


          // Creates Text
          text = "";
          if (isSuper) {text += "B";}
          if (isLock) {text += "L";}
          chuzzleGrid[x][y]->setText(text);
        }
      }

        FileIsOpen = true;

        // Update Items on the screen
        LLlab10->setText("Current Score: " + QString::fromStdString(std::to_string(save.GetScore())));
        LLlab30->setText("Current Level: " + QString::fromStdString(std::to_string(save.GetLevel())));
        LLlab50->setText("Current Scrambles: " + QString::fromStdString(std::to_string(save.GetScrambles())));
        //LLlab71->setText(QString::fromStdString(std::to_string(save.GetBottle())));

    }

    // Save File!
    void SaveFile() {
      save.NewSave();
    }


    // Formatting
    QGroupBox *window = new QGroupBox(this);
    QHBoxLayout *Mainlayout = new QHBoxLayout;

    QHBoxLayout *Leftlayout = new QHBoxLayout;
    QHBoxLayout *Rightlayout = new QHBoxLayout;

    QVBoxLayout *gridLL = new QVBoxLayout;
    //QGridLayout* gridLL = new QGridLayout();
    QGridLayout* gridLR = new QGridLayout();
    QVBoxLayout* boxLR = new QVBoxLayout();
    QHBoxLayout* bottomLR = new QHBoxLayout();

    QGridLayout* gridRL = new QGridLayout();
    QGridLayout* gridRR = new QGridLayout();

    QHBoxLayout *spacer1 = new QHBoxLayout;
    QHBoxLayout *spacer2 = new QHBoxLayout;
    QHBoxLayout *spacer3 = new QHBoxLayout;


    // For the RL segment (the board!).
    QVector<QVector<QPushButton*>> chuzzleGrid;


    // For LL Grid
    QPushButton *LLbtn00 = Button();
    QLineEdit *LLlin01 = LineEdit();
    QLabel *LLlab10 = new QLabel;
    QLabel *LLlab11 = new QLabel;

    QPushButton *LLbtn20 = Button();
    QLineEdit *LLlin21 = LineEdit();
    QLabel *LLlab30 = new QLabel;
    QLabel *LLlab31 = new QLabel;

    QPushButton *LLbtn40 = Button();
    QLineEdit *LLlin41 = LineEdit();

    QLabel *LLlab50 = new QLabel;
    QLabel *LLlab51 = new QLabel;

    QPushButton *LLbtn60 = Button();
    QLineEdit *LLlin61 = LineEdit();

    QLabel *LLlab70 = new QLabel;
    QLabel *LLlab71 = new QLabel;
    // End of LL Grid


    // LR Grid
    QLabel *currentPaintLbl = new QLabel;
    QLabel *currentTypelbl = new QLabel;
    QLabel *currentSaveLbl = new QLabel;






};



#endif

